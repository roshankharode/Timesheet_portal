package com.bezkoder.spring.security.postgresql.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bezkoder.spring.security.postgresql.models.ResourceName;

@Repository
@Qualifier("ResourceReposistory")
public interface ResourceReposistory extends JpaRepository<ResourceName, String> {

	
	
}
