package com.bezkoder.spring.security.postgresql.security.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bezkoder.spring.security.postgresql.models.ResourceName;
import com.bezkoder.spring.security.postgresql.repository.ResourceReposistory;

@Service
public class ResourceNameImpl {

	@Autowired
	ResourceReposistory resourceRepository;
	
	
	public List<ResourceName> ShowAllResources() {
		return resourceRepository.findAll();
	}
	
}
