package com.bezkoder.spring.security.postgresql.models;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.*;

@Entity
//@Table(name = "Resource Names")
public class ResourceName {

	@Id
	@Column
	private int ResourceId;

	@Column
	private String resourceName;

	public ResourceName(int ResourceId, String resourceName) {
		this.ResourceId = ResourceId;
		this.resourceName = resourceName;
	}

	public void setResourceId(int ResourceId) {
		this.ResourceId = ResourceId;
	}

	public void setresourceName(String resourceName) {

	}
}
